package test;

import java.util.Scanner;

public class Tdsae {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	try {
		System.out.println("1~10 사이의 숫자를 입력하세요");
		int n = sc.nextInt();
		if(n<1 || n > 10) {
			throw new RuntimeException();
			}
		for (int i = 1; i <= n; i++) {
  			for (int j = 1; j <= i; j++) {
  				System.out.printf("*");
  			}
  			System.out.println();
    	  }
    	 System.out.println("----------------------");
    	 for (int i = n; i >= 1; i--) {
 			for (int j = 1; j <= i; j++) {
 				System.out.print("*");
 			}
 			System.out.println();
    	 }
    	 System.out.println("----------------------");
    	 int b = n * 2 - 1;
 		 int m = b / 2;
 		 for (int i = 0; i < n; i++) {
 			for (int j = 0; j < b; j++) {
 				if (j >= m - i && j <= m + i)
 					System.out.print("*");
 				else
 					System.out.print(" ");
 				}
 			System.out.println();
 		 	}
		}catch(RuntimeException e){
			System.out.println(e.getMessage());
			System.out.println("1~10 숫자만 입력하세요");
			
		}
	}
}
